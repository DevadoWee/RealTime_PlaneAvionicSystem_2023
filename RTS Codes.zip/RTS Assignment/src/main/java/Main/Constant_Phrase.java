/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

/**
 *
 * @author David
 */
public class Constant_Phrase {
    private Constant_Phrase(){}
    
    public static final String WingFlapsUpInstruction = "Up";
    public static final String WingFlapsDownInstruction = "Down";
    public static final String CabinPressurizationMoreInstruction = "Pump More";
    public static final String CabinPressurizationCabinLossInstruction = "Turn Pump To High";
    public static final String CabinPressurizationLessInstruction = "Pump Less";
    public static final String RudderRightInstruction = "Right";
    public static final String RudderLeftInstruction = "Left";
    public static final String EngineFastInstruction = "Speeds Up";
    public static final String EngineSlowInstruction = "Slows Down";
}
