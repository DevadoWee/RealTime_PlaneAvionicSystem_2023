/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Actuator.CabinPressurization;
import Actuator.Engine;
import Actuator.Rudder;
import Actuator.WingFlaps;
import Unexpected_Events.Altitude_SensorBackup;
import Unexpected_Events.LossOfCabinPressure;
import com.mycompany.FlightControl.BM_sendActuatorFlightControl;
import com.mycompany.FlightControl.getSensorFlightControl;
import com.mycompany.FlightControl.sendActuatorFlightControl;
import com.mycompany.Sensor.Altitude_Sensor;
import com.mycompany.Sensor.Cabin_Sensor;
import com.mycompany.Sensor.Direction_Sensor;
import com.mycompany.Sensor.Speed_Sensor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;


/**
 *
 * @author David
 */
public class Main {
    public static void main(String[] args) throws IOException {
        
//        org.openjdk.jmh.Main.main(args);
        
        AtomicInteger currentAltitude = new AtomicInteger(15000);
        AtomicInteger currentPressure = new AtomicInteger(1150); //11.50
        AtomicInteger currentDirection = new AtomicInteger(0); //00.00 = 0000
        AtomicInteger currentSpeed = new AtomicInteger(900);
        
        AtomicInteger startLossOfCabinPressure = new AtomicInteger(0); // 1 means yes for cabin sensor
        AtomicInteger StatusLossOfCabinPressure = new AtomicInteger(0); // 1 means yes for FlightControl

        LinkedBlockingQueue<String> AltitudeQueue = new LinkedBlockingQueue<>(10);
        LinkedBlockingQueue<String> CabinPressureQueue = new LinkedBlockingQueue<>(10);
        LinkedBlockingQueue<String> DirectionQueue = new LinkedBlockingQueue<>(10);
        LinkedBlockingQueue<String> SpeedQueue = new LinkedBlockingQueue<>(10);
       
        ScheduledExecutorService Events = Executors.newScheduledThreadPool(2);
        Events.execute(new LossOfCabinPressure(startLossOfCabinPressure));
//        Events.execute(new Altitude_SensorBackup(currentAltitude));

        //sensors
        ScheduledExecutorService Sensors = Executors.newScheduledThreadPool(4);
        Sensors.scheduleAtFixedRate(new Altitude_Sensor(currentAltitude),0,1500,TimeUnit.MILLISECONDS);
        Sensors.scheduleAtFixedRate(new Cabin_Sensor(currentPressure,startLossOfCabinPressure),0,1500,TimeUnit.MILLISECONDS);
        Sensors.scheduleAtFixedRate(new Direction_Sensor(currentDirection),0,1500,TimeUnit.MILLISECONDS);
        Sensors.scheduleAtFixedRate(new Speed_Sensor(currentSpeed),0,1500,TimeUnit.MILLISECONDS);
        
//        flight control
        ScheduledExecutorService FlightControl = Executors.newScheduledThreadPool(2);
        FlightControl.execute(new getSensorFlightControl(AltitudeQueue,CabinPressureQueue,DirectionQueue,SpeedQueue));
        FlightControl.scheduleAtFixedRate(new sendActuatorFlightControl(AltitudeQueue,CabinPressureQueue,DirectionQueue,SpeedQueue,StatusLossOfCabinPressure),500,1500,TimeUnit.MILLISECONDS);
//
        ScheduledExecutorService Actuators = Executors.newScheduledThreadPool(4);
        Actuators.execute(new WingFlaps(currentAltitude));
        Actuators.execute(new CabinPressurization(currentPressure));
        Actuators.execute(new Rudder(currentDirection));
        Actuators.execute(new Engine(currentSpeed));
        
    }
}
