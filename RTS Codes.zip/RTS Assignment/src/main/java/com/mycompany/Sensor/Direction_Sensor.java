/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Sensor;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author David
 */
//Sense pressure
public class Direction_Sensor implements Runnable{
    Random rand = new Random();
    double changeInDirection;
    AtomicInteger currentDirection;
    
    public Direction_Sensor(AtomicInteger currentDirection){
        this.currentDirection =  currentDirection;
    }
    @Override
    public void run() {
        Thread.currentThread().setName("Direction Sensor");
        
        changeInDirection = rand.doubles(-10,10)
                                    .findFirst()           
                                    .getAsDouble(); 
        currentDirection.getAndAdd((int) (changeInDirection * 100));
        
        DecimalFormat df = new DecimalFormat("0.00");
        double convertedCurrentDirection = currentDirection.doubleValue() / 100;
        String strCurrentDirection = df.format(convertedCurrentDirection);
//        String strChangeInDirection = df.format(changeInDirection);
//        
//        System.out.println(Thread.currentThread().getName() + " -- Change in Direction: "+ strChangeInDirection + "°");
        System.out.println(Thread.currentThread().getName() + " -- Current Direction: " + strCurrentDirection + "°");
        
        try{
            Direction_Sensor.sendDirection(currentDirection.toString());
        }catch(Exception e){
            
        }
    }
    
    //send altitude to flight control
    static void sendDirection(String currentDirection) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Direction";

        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();

        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){

            //3.create a channel using the connection
            Channel chan = con.createChannel();

            //4.Declare a queue or exchange
    //            chan.queueDeclare(qName, false, false, false, null); 
            chan.exchangeDeclare(ex,"direct"); //type direct/fanout

            //5.send/publish message
            chan.basicPublish(ex,key,null,currentDirection.getBytes()); //exchange, name(define which receiver will receive, else "")
        }
    }
}
