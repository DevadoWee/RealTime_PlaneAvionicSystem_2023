/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.Sensor;


import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David
 */
//Sense altitude
public class Altitude_Sensor implements Runnable{
    Random rand = new Random();
    double changeInAltitude;
    AtomicInteger currentAltitude;
    
    public Altitude_Sensor(AtomicInteger currentAltitude){
        this.currentAltitude =  currentAltitude;
    }
    @Override
    public void run() {
        Thread.currentThread().setName("Altitude Sensor");
        double ori_altitude = currentAltitude.doubleValue(); 
        changeInAltitude = rand.ints(-500,500)
                                .findFirst()           
                                .getAsInt(); 
        currentAltitude.getAndAdd((int) changeInAltitude);
        
        DecimalFormat df = new DecimalFormat("0.00");
        String strCurrentAltitude = df.format(currentAltitude);
//        String strChangeInAltitude = df.format(changeInAltitude);
        
        System.out.println(Thread.currentThread().getName() + " -- Current altitude: " + strCurrentAltitude + "ft");
        
        try{
            Altitude_Sensor.sendAltitude(strCurrentAltitude);
        }catch(Exception e){
            
        }
    }
    
    public static void sendAltitude(String currentAltitude) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Altitude";

        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();

        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){

            //3.create a channel using the connection
            Channel chan = con.createChannel();

            //4.Declare a queue or exchange
    //            chan.queueDeclare(qName, false, false, false, null); 
            chan.exchangeDeclare(ex,"direct"); //type direct/fanout

            //5.send/publish message
            chan.basicPublish(ex,key,null,currentAltitude.getBytes()); //exchange, name(define which receiver will receive, else "")
        }
    }
}
