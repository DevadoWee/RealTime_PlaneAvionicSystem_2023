/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Sensor;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Warmup;

/**
 *
 * @author David
 */
//cabin pressure
//Sense pressure

public class Cabin_Sensor implements Runnable{
    Random rand = new Random();
    double changeInPressure;
    AtomicInteger currentPressure;
    AtomicInteger startLossOfCabinPressure;
    
    public Cabin_Sensor(AtomicInteger currentPressure, AtomicInteger startLossOfCabinPressure){
        this.currentPressure =  currentPressure;
        this.startLossOfCabinPressure = startLossOfCabinPressure;
    }
    
    public void run() {
        Thread.currentThread().setName("Cabin Sensor");
        if (startLossOfCabinPressure.get() == 1){
            try{
                System.out.println(Thread.currentThread().getName() + " -- Current Cabin Pressure: " + 0 + "PSI");
                Cabin_Sensor.sendCabinPressure("0");
                return;
            }catch(Exception e){
                System.out.println("Fail Event");
            }
        }
        
        changeInPressure = rand.doubles(-0.5,0.5)
                                    .findFirst()           
                                    .getAsDouble(); 
        currentPressure.addAndGet((int) (changeInPressure * 100));
        
        ///special from others because cannot double unless its atomic reference and several feature is limited
        DecimalFormat df = new DecimalFormat("0.00");
        double convertedCurrentPressure = currentPressure.doubleValue() / 100;
        String strCurrentPressure = df.format(convertedCurrentPressure);
//        String strChangeInPressure = df.format(changeInPressure);
//        
//        System.out.println(Thread.currentThread().getName() + " -- Change in Cabin Pressure: "+ strChangeInPressure + "PSI");
        System.out.println(Thread.currentThread().getName() + " -- Current Cabin Pressure: " + strCurrentPressure + "PSI");
        
        try{
            Cabin_Sensor.sendCabinPressure(currentPressure.toString());
        }catch(Exception e){
            
        }
    }
    //send altitude to flight control
    static void sendCabinPressure(String currentPressure) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "CabinPressure";

        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();

        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){

            //3.create a channel using the connection
            Channel chan = con.createChannel();

            //4.Declare a queue or exchange
    //            chan.queueDeclare(qName, false, false, false, null); 
            chan.exchangeDeclare(ex,"direct"); //type direct/fanout

            //5.send/publish message
            chan.basicPublish(ex,key,null,currentPressure.getBytes()); //exchange, name(define which receiver will receive, else "")
        }
    }
}
