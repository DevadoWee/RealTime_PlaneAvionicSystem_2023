/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.FlightControl;

import static Main.Constant_Phrase.CabinPressurizationCabinLossInstruction;
import static Main.Constant_Phrase.CabinPressurizationLessInstruction;
import static Main.Constant_Phrase.CabinPressurizationMoreInstruction;
import static Main.Constant_Phrase.EngineFastInstruction;
import static Main.Constant_Phrase.EngineSlowInstruction;
import static Main.Constant_Phrase.RudderLeftInstruction;
import static Main.Constant_Phrase.RudderRightInstruction;
import static Main.Constant_Phrase.WingFlapsDownInstruction;
import static Main.Constant_Phrase.WingFlapsUpInstruction;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Fork;
import org.openjdk.jmh.annotations.Measurement;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Warmup;

/**
 *
 * @author David
 */
public class BM_sendActuatorFlightControl {
    @Benchmark
    @BenchmarkMode(Mode.AverageTime) // find the average performance time
    @Measurement(iterations = 4) // n of iteration
    @OutputTimeUnit(TimeUnit.NANOSECONDS) // display in what time unit
    @Warmup(iterations = 2) // literally
    @Fork(5) // Every iteration is split to a group of n
    public static boolean sendInstruction() {
        try{
            ///Linkedlist
            LinkedBlockingQueue<String> AltitudeQueue  = new LinkedBlockingQueue<>(Arrays.asList("14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234"));
            LinkedBlockingQueue<String> CabinPressureQueue = new LinkedBlockingQueue<>(Arrays.asList("1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079"));
            LinkedBlockingQueue<String> DirectionQueue = new LinkedBlockingQueue<>(Arrays.asList("4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43"));
            LinkedBlockingQueue<String> SpeedQueue = new LinkedBlockingQueue<>(Arrays.asList("890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901"));
            ////linkedlist
            
            ///No queue
//            LinkedList<String> AltitudeQueue  = new LinkedList<>(Arrays.asList("14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234"));
//            LinkedList<String> CabinPressureQueue = new LinkedList<>(Arrays.asList("1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079"));
//            LinkedList<String> DirectionQueue = new LinkedList<>(Arrays.asList("4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43"));
//            LinkedList<String> SpeedQueue = new LinkedList<>(Arrays.asList("890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901"));
            ///No queue
            
            AtomicInteger StatusLossOfCabinPressure = new AtomicInteger(0);

            ///arraylist
//            ArrayBlockingQueue<String> AltitudeQueue  = new ArrayBlockingQueue<>(100,true,Arrays.asList("14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234"));
//            ArrayBlockingQueue<String> CabinPressureQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079"));
//            ArrayBlockingQueue<String> DirectionQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43"));
//            ArrayBlockingQueue<String> SpeedQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901"));
            ///arraylist
            
            Thread.currentThread().setName("Flight Control Output");
            String altitude = null;
            String pressure = null;
            String direction = null;
            String speed = null;
            
            //////////Threads
//            Thread t1 = new Thread((Runnable) new getAltitude(AltitudeQueue));
//            Thread t2 = new Thread((Runnable) new getPressure(CabinPressureQueue));
//            Thread t3 = new Thread((Runnable) new getDirection(DirectionQueue));
//            Thread t4 = new Thread((Runnable) new getSpeed(SpeedQueue));
//            
//            t1.start();
//            t2.start();
//            t3.start();
//            t4.start();
//            t1.join();
//            t2.join();
//            t3.join();
//            t4.join();
            ///////////Threads
            
            while(!AltitudeQueue.isEmpty()){
                altitude = AltitudeQueue.take();
            }
            while(!CabinPressureQueue.isEmpty()){
                pressure = CabinPressureQueue.take();
            }
            while(!DirectionQueue.isEmpty()){
                direction = DirectionQueue.take();
            }
            while(!SpeedQueue.isEmpty()){
                speed = SpeedQueue.take();
            }

                ///////no queue
//            altitude = AltitudeQueue.getLast();
//            pressure = CabinPressureQueue.getLast();
//            direction = DirectionQueue.getLast();
//            speed = SpeedQueue.getLast();
//            
//            AltitudeQueue.clear();
//            CabinPressureQueue.clear();
//            DirectionQueue.clear();
//            SpeedQueue.clear();
                /////no queue
                
            if ((altitude != null) && (StatusLossOfCabinPressure.get() <= 0)){ //if altitude is not empty, and its not cabinloss status
                //15000 is starting altitude
                //altitude must stay between 14500 - 15500
                if(Double.parseDouble(altitude) < 14500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsUpInstruction);
                    sendToActuatorDirect(WingFlapsUpInstruction,1);
                }else if(Double.parseDouble(altitude) > 15500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsDownInstruction);
                    sendToActuatorDirect(WingFlapsDownInstruction,1);
                }
            }
            if (pressure != null){
                if(Double.parseDouble(pressure) > 100){
                    StatusLossOfCabinPressure.getAndSet(0);
                }
                if(Double.parseDouble(pressure) < 10){
                    System.out.println(Thread.currentThread().getName() + " ........\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# "
                                                                            + "\n------------> Instruction To Cabin Pressurization - " + CabinPressurizationCabinLossInstruction 
                                                                            + "\n------------> Instruction To WingFlaps - " + WingFlapsDownInstruction 
                                                                            + "\n------------> Instruction To Engine - " + EngineSlowInstruction
                                                                            + "\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# ");
                    StatusLossOfCabinPressure.getAndIncrement();
                    sendToActuatorFanout("CABINLOSS");
                }
                else if(Double.parseDouble(pressure) < 1100){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationMoreInstruction);
                    sendToActuatorDirect(CabinPressurizationMoreInstruction,2);
                    
                }else if (Double.parseDouble(pressure) > 1200){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationLessInstruction);
                    sendToActuatorDirect(CabinPressurizationLessInstruction,2);
                }
            }
            //0.8 = 800
            if (direction != null){
                if(Double.parseDouble(direction) < -800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderRightInstruction);
                    sendToActuatorDirect(RudderRightInstruction,3);
                    
                }else if (Double.parseDouble(direction) > 800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderLeftInstruction);
                    sendToActuatorDirect(RudderLeftInstruction,3);
                }
            }
            
            if ((speed != null)  && (StatusLossOfCabinPressure.get() <= 0)){
                if(Double.parseDouble(speed) < 880){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineFastInstruction);
                    sendToActuatorDirect(EngineFastInstruction,4);
                    
                }else if (Double.parseDouble(speed) > 926){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineSlowInstruction);
                    sendToActuatorDirect(EngineSlowInstruction,4);
                }
            }
            return true;
        }catch(Exception ex2){}
            return false;
    }
    
    @Benchmark
    @BenchmarkMode(Mode.AverageTime) // find the average performance time
    @Measurement(iterations = 4) // n of iteration
    @OutputTimeUnit(TimeUnit.NANOSECONDS) // display in what time unit
    @Warmup(iterations = 2) // literally
    @Fork(5) // Every iteration is split to a group of n
    public static boolean sendInstruction2() {
        try{
            ///Linkedlist
            LinkedBlockingQueue<String> AltitudeQueue  = new LinkedBlockingQueue<>(Arrays.asList("14675"));
            LinkedBlockingQueue<String> CabinPressureQueue = new LinkedBlockingQueue<>(Arrays.asList("1034"));
            LinkedBlockingQueue<String> DirectionQueue = new LinkedBlockingQueue<>(Arrays.asList("4.34"));
            LinkedBlockingQueue<String> SpeedQueue = new LinkedBlockingQueue<>(Arrays.asList("890"));
            ////linkedlist
            AtomicInteger StatusLossOfCabinPressure = new AtomicInteger(0);

            ///No queue
//            LinkedList<String> AltitudeQueue  = new LinkedList<>(Arrays.asList("14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234"));
//            LinkedList<String> CabinPressureQueue = new LinkedList<>(Arrays.asList("1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079"));
//            LinkedList<String> DirectionQueue = new LinkedList<>(Arrays.asList("4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43"));
//            LinkedList<String> SpeedQueue = new LinkedList<>(Arrays.asList("890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901"));
            ///No queue
            
            ///arraylist
//            ArrayBlockingQueue<String> AltitudeQueue  = new ArrayBlockingQueue<>(100,true,Arrays.asList("14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234","14675", "15745", "16834", "14999", "16234"));
//            ArrayBlockingQueue<String> CabinPressureQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079","1034","1090","1243","1189","1079"));
//            ArrayBlockingQueue<String> DirectionQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43","4.34","7.22","9.23","1.23","3.43"));
//            ArrayBlockingQueue<String> SpeedQueue = new ArrayBlockingQueue<>(100,true,Arrays.asList("890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901","890","910","899","918","901"));
            ///arraylist
            
            Thread.currentThread().setName("Flight Control Output");
            String altitude = null;
            String pressure = null;
            String direction = null;
            String speed = null;
            
//            Thread t1 = new Thread((Runnable) new getAltitude(AltitudeQueue));
//            Thread t2 = new Thread((Runnable) new getPressure(CabinPressureQueue));
//            Thread t3 = new Thread((Runnable) new getDirection(DirectionQueue));
//            Thread t4 = new Thread((Runnable) new getSpeed(SpeedQueue));
//            
//            t1.start();
//            t2.start();
//            t3.start();
//            t4.start();
//            t1.join();
//            t2.join();
//            t3.join();
//            t4.join();
            while(!AltitudeQueue.isEmpty()){
                altitude = AltitudeQueue.take();
            }
            while(!CabinPressureQueue.isEmpty()){
                pressure = CabinPressureQueue.take();
            }
            while(!DirectionQueue.isEmpty()){
                direction = DirectionQueue.take();
            }
            while(!SpeedQueue.isEmpty()){
                speed = SpeedQueue.take();
            }
//            
            
            if ((altitude != null) && (StatusLossOfCabinPressure.get() <= 0)){ //if altitude is not empty, and its not cabinloss status
                //15000 is starting altitude
                //altitude must stay between 14500 - 15500
                if(Double.parseDouble(altitude) < 14500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsUpInstruction);
                    sendToActuatorDirect(WingFlapsUpInstruction,1);
                }else if(Double.parseDouble(altitude) > 15500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsDownInstruction);
                    sendToActuatorDirect(WingFlapsDownInstruction,1);
                }
            }
            if (pressure != null){
                if(Double.parseDouble(pressure) > 100){
                    StatusLossOfCabinPressure.getAndSet(0);
                }
                if(Double.parseDouble(pressure) < 10){
                    System.out.println(Thread.currentThread().getName() + " ........\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# "
                                                                            + "\n------------> Instruction To Cabin Pressurization - " + CabinPressurizationCabinLossInstruction 
                                                                            + "\n------------> Instruction To WingFlaps - " + WingFlapsDownInstruction 
                                                                            + "\n------------> Instruction To Engine - " + EngineSlowInstruction
                                                                            + "\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# ");
                    StatusLossOfCabinPressure.getAndIncrement();
                    sendToActuatorFanout("CABINLOSS");
                }
                else if(Double.parseDouble(pressure) < 1100){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationMoreInstruction);
                    sendToActuatorDirect(CabinPressurizationMoreInstruction,2);
                    
                }else if (Double.parseDouble(pressure) > 1200){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationLessInstruction);
                    sendToActuatorDirect(CabinPressurizationLessInstruction,2);
                }
            }
            //0.8 = 800
            if (direction != null){
                if(Double.parseDouble(direction) < -800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderRightInstruction);
                    sendToActuatorDirect(RudderRightInstruction,3);
                    
                }else if (Double.parseDouble(direction) > 800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderLeftInstruction);
                    sendToActuatorDirect(RudderLeftInstruction,3);
                }
            }
            
            if ((speed != null)  && (StatusLossOfCabinPressure.get() <= 0)){
                if(Double.parseDouble(speed) < 880){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineFastInstruction);
                    sendToActuatorDirect(EngineFastInstruction,4);
                    
                }else if (Double.parseDouble(speed) > 926){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineSlowInstruction);
                    sendToActuatorDirect(EngineSlowInstruction,4);
                }
            }
            return true;
        }catch(Exception ex2){}
            return false;
    }
    
    static void sendToActuatorDirect(String instruction, int exType) throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = null;
        
        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();
        
        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){

            //3.create a channel using the connection
            Channel chan = con.createChannel();
            //engine // landing gear // oxygen masks
            switch(exType) {
                case 1: // to WingFlaps
                    key = "WingFlaps";
                    break;
                    
                case 2: //CabinPressurization
                    key = "CabinPressurization";
                    break;
                    
                case 3: //Rudder
                    key = "Rudder";
                    break;
                    
                case 4: //Engine
                    key = "Engine";
                    break;
                default:
                  // code block
            }
            //4.Declare a queue or exchange
            chan.exchangeDeclare(ex,"direct"); //type direct/fanout
            //5.send/publish message
            chan.basicPublish(ex,key,null,instruction.getBytes()); //exchange, name(define which receiver will receive, else "")
        }
    }
    
    static void sendToActuatorFanout(String instruction) throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchangeCABINLOSS";
        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();
        
        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){
        
            //3.create a channel using the connection
            Channel chan = con.createChannel();

            //4.Declare a queue or exchange
//            chan.queueDeclare(qName, false, false, false, null); 
            chan.exchangeDeclare(ex,"fanout"); //type direct/fanout

            //5.send/publish message
            chan.basicPublish(ex,"",null,instruction.getBytes()); //exchange, name(define which receiver will receive, else "")
            
        }
    }

}

class getAltitude implements Runnable{
    LinkedBlockingQueue<String> AltitudeQueue;
    
    public getAltitude(LinkedBlockingQueue<String> AltitudeQueue) {
        this.AltitudeQueue = AltitudeQueue;
    }
    
    @Override
    public void run() {
        while(AltitudeQueue.size() != 1){
            try {
                AltitudeQueue.take();
            } catch (Exception ee) {}
        }
    }
}

class getPressure implements Runnable{
    LinkedBlockingQueue<String> PressureQueue;
    
    public getPressure(LinkedBlockingQueue<String> PressureQueue) {
        this.PressureQueue = PressureQueue;
    }
    
    @Override
    public void run() {
        while(PressureQueue.size() != 1){
            try {
                PressureQueue.take();
            } catch (Exception ee) {}
        }
    }
}

class getDirection implements Runnable{
    LinkedBlockingQueue<String> DirectionQueue;
    
    public getDirection(LinkedBlockingQueue<String> DirectionQueue) {
        this.DirectionQueue = DirectionQueue;
    }
    
    @Override
    public void run() {
        while(DirectionQueue.size() != 1){
            try {
                DirectionQueue.take();
            } catch (Exception ee) {}
        }
    }
}

class getSpeed implements Runnable{
    LinkedBlockingQueue<String> SpeedQueue;
    
    public getSpeed(LinkedBlockingQueue<String> SpeedQueue) {
        this.SpeedQueue = SpeedQueue;
    }
    
    @Override
    public void run() {
        while(SpeedQueue.size() != 1){
            try {
                SpeedQueue.take();
            } catch (Exception ee) {}
        }
    }
}