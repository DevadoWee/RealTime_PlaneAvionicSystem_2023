/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.FlightControl;

import static Main.Constant_Phrase.CabinPressurizationCabinLossInstruction;
import static Main.Constant_Phrase.CabinPressurizationLessInstruction;
import static Main.Constant_Phrase.CabinPressurizationMoreInstruction;
import static Main.Constant_Phrase.EngineFastInstruction;
import static Main.Constant_Phrase.EngineSlowInstruction;
import static Main.Constant_Phrase.RudderLeftInstruction;
import static Main.Constant_Phrase.RudderRightInstruction;
import static Main.Constant_Phrase.WingFlapsDownInstruction;
import static Main.Constant_Phrase.WingFlapsUpInstruction;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author David
 */
public class sendActuatorFlightControl implements Runnable{
    LinkedBlockingQueue<String> AltitudeQueue;
    LinkedBlockingQueue<String> CabinPressureQueue;
    LinkedBlockingQueue<String> DirectionQueue;
    LinkedBlockingQueue<String> SpeedQueue;
    AtomicInteger StatusLossOfCabinPressure;
    
    public sendActuatorFlightControl(LinkedBlockingQueue<String> AltitudeQueue,LinkedBlockingQueue<String> CabinPressureQueue,LinkedBlockingQueue<String> DirectionQueue,LinkedBlockingQueue<String> SpeedQueue, AtomicInteger StatusLossOfCabinPressure){
        this.AltitudeQueue = AltitudeQueue;
        this.CabinPressureQueue = CabinPressureQueue;
        this.DirectionQueue = DirectionQueue;
        this.SpeedQueue = SpeedQueue;
        this.StatusLossOfCabinPressure = StatusLossOfCabinPressure;
    }
    
    @Override
    public void run() {
        try{
            Thread.currentThread().setName("Flight Control Output");
            String altitude = null;
            String pressure = null;
            String direction = null;
            String speed = null;
            while(!AltitudeQueue.isEmpty()){
                altitude = AltitudeQueue.take();
            }
            while(!CabinPressureQueue.isEmpty()){
                pressure = CabinPressureQueue.take();
            }
            while(!DirectionQueue.isEmpty()){
                direction = DirectionQueue.take();
            }
            while(!SpeedQueue.isEmpty()){
                speed = SpeedQueue.take();
            }
            
            if ((altitude != null) && (StatusLossOfCabinPressure.get() <= 0)){ //if altitude is not empty, and its not cabinloss status
                //15000 is starting altitude
                //altitude must stay between 14500 - 15500
                if(Double.parseDouble(altitude) < 14500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsUpInstruction);
                    sendToActuatorDirect(WingFlapsUpInstruction,1);
                }else if(Double.parseDouble(altitude) > 15500){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To WingFlaps - "+ WingFlapsDownInstruction);
                    sendToActuatorDirect(WingFlapsDownInstruction,1);
                }
            }
            if (pressure != null){
                if(Double.parseDouble(pressure) > 100){
                    StatusLossOfCabinPressure.getAndSet(0);
                }
                if(Double.parseDouble(pressure) < 10){
                    System.out.println(Thread.currentThread().getName() + " ........\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# "
                                                                            + "\n------------> Instruction To Cabin Pressurization - " + CabinPressurizationCabinLossInstruction 
                                                                            + "\n------------> Instruction To WingFlaps - " + WingFlapsDownInstruction 
                                                                            + "\n------------> Instruction To Engine - " + EngineSlowInstruction
                                                                            + "\n############# CABIN LOSS CABIN LOSS CABIN LOSS ############# ");
                    StatusLossOfCabinPressure.getAndIncrement();
                    sendToActuatorFanout("CABINLOSS");
                }
                else if(Double.parseDouble(pressure) < 1100){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationMoreInstruction);
                    sendToActuatorDirect(CabinPressurizationMoreInstruction,2);
                    
                }else if (Double.parseDouble(pressure) > 1200){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Cabin Pressurization - " + CabinPressurizationLessInstruction);
                    sendToActuatorDirect(CabinPressurizationLessInstruction,2);
                }
            }
            //0.8 = 800
            if (direction != null){
                if(Double.parseDouble(direction) < -800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderRightInstruction);
                    sendToActuatorDirect(RudderRightInstruction,3);
                    
                }else if (Double.parseDouble(direction) > 800){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Rudder - " + RudderLeftInstruction);
                    sendToActuatorDirect(RudderLeftInstruction,3);
                }
            }
            
            if ((speed != null)  && (StatusLossOfCabinPressure.get() <= 0)){
                if(Double.parseDouble(speed) < 880){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineFastInstruction);
                    sendToActuatorDirect(EngineFastInstruction,4);
                    
                }else if (Double.parseDouble(speed) > 926){
                    System.out.println(Thread.currentThread().getName() + " ## Instruction To Engine - " + EngineSlowInstruction);
                    sendToActuatorDirect(EngineSlowInstruction,4);
                }
            }
            
        }catch(Exception ex2){}
    }
    
    static void sendToActuatorDirect(String instruction, int exType) throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = null;
        
        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();
        
        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){

            //3.create a channel using the connection
            Channel chan = con.createChannel();
            //engine // landing gear // oxygen masks
            switch(exType) {
                case 1: // to WingFlaps
                    key = "WingFlaps";
                    break;
                    
                case 2: //CabinPressurization
                    key = "CabinPressurization";
                    break;
                    
                case 3: //Rudder
                    key = "Rudder";
                    break;
                    
                case 4: //Engine
                    key = "Engine";
                    break;
                default:
                  // code block
            }
            //4.Declare a queue or exchange
            chan.exchangeDeclare(ex,"direct"); //type direct/fanout
            //5.send/publish message
            chan.basicPublish(ex,key,null,instruction.getBytes()); //exchange, name(define which receiver will receive, else "")
        }
    }
    
    static void sendToActuatorFanout(String instruction) throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchangeCABINLOSS";
        //1.create connection
        ConnectionFactory cf = new ConnectionFactory();
        
        //2.use Factory to create a connection
        try(Connection con = cf.newConnection()){
        
            //3.create a channel using the connection
            Channel chan = con.createChannel();

            //4.Declare a queue or exchange
//            chan.queueDeclare(qName, false, false, false, null); 
            chan.exchangeDeclare(ex,"fanout"); //type direct/fanout

            //5.send/publish message
            chan.basicPublish(ex,"",null,instruction.getBytes()); //exchange, name(define which receiver will receive, else "")
            
        }
    }

    
}