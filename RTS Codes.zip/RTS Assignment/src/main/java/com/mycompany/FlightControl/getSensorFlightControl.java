/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.FlightControl;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David
 */

//PriorityBlockingQueue.remainingCapacity() 
public class getSensorFlightControl implements Runnable {
    LinkedBlockingQueue<String> AltitudeQueue;
    LinkedBlockingQueue<String> CabinPressureQueue;
    LinkedBlockingQueue<String> DirectionQueue;
    LinkedBlockingQueue<String> SpeedQueue;
    
        
    public getSensorFlightControl(LinkedBlockingQueue<String> AltitudeQueue,LinkedBlockingQueue<String> CabinPressureQueue,LinkedBlockingQueue<String> DirectionQueue,LinkedBlockingQueue<String> SpeedQueue){
        this.AltitudeQueue = AltitudeQueue;
        this.CabinPressureQueue = CabinPressureQueue;
        this.DirectionQueue = DirectionQueue;
        this.SpeedQueue = SpeedQueue;
    }
    
    @Override
    public void run() {
        Thread.currentThread().setName("Flight Control Input");
        try {
            getAltitude(AltitudeQueue);
            getCabinPressure(CabinPressureQueue);
            getDirection(DirectionQueue);
            getSpeed(SpeedQueue);
            
        } catch (Exception ex) {}
    }  
    
    public static void getAltitude(LinkedBlockingQueue<String> AltitudeQueue) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Altitude";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""
        
        //thread name
        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            System.out.println(threadName + " ## Received Altitude: " + m + "ft");
            try {
                AltitudeQueue.put(m);
            } catch (Exception ex1) {}
        },x->{});
    }
    
    public static void getCabinPressure(LinkedBlockingQueue<String> CabinPressureQueue) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "CabinPressure";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            System.out.println(threadName + " ## Received Cabin Pressure: " + (Double.parseDouble(m) / 100) + "PSI");
            try {
                CabinPressureQueue.put(m);
            } catch (Exception ex1) {}
        },x->{});
    }
    
    public static void getDirection(LinkedBlockingQueue<String> DirectionQueue) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Direction";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            System.out.println(threadName + " ## Received Direction: " + (Double.parseDouble(m)/100) + "°");
            try {
                DirectionQueue.put(m);
            } catch (Exception ex1) {}
        },x->{});
    }
    
    public static void getSpeed(LinkedBlockingQueue<String> SpeedQueue) throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Speed";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            System.out.println(threadName + " ## Received Speed: " + m + "km/h");
            try {
                SpeedQueue.put(m);
            } catch (Exception ex1) {}
        },x->{});
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

