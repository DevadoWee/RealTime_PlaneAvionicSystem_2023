/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actuator;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author David
 */
public class Rudder implements Runnable{
    static AtomicInteger currentDirection;
    public Rudder(AtomicInteger currentDirection){
        this.currentDirection = currentDirection;
    }
    
    @Override
    public void run() {
        try {
            Thread.currentThread().setName("Tail Rudder Systems");
            getInstruction();
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    public static void getInstruction() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = "Rudder";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            Thread.currentThread().setName("Tail Rudder Systems (1)");
            System.out.println(threadName + " -> Tail Rudder Moves ~~ "+ m + "  -> Direction Resetted to 0°");
            currentDirection.set(0);
        },x->{});
    }
}
