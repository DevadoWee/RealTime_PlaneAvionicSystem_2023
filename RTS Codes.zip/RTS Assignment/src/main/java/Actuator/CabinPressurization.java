/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actuator;

import static Main.Constant_Phrase.CabinPressurizationCabinLossInstruction;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author David
 */
public class CabinPressurization implements Runnable{
    static AtomicInteger currentPressure;
    public CabinPressurization(AtomicInteger currentPressure){
        this.currentPressure = currentPressure;
    }
    
    @Override
    public void run() {
        try {
            Thread.currentThread().setName("Cabin Pressurization Systems");
            getInstruction();
            getInstructionCABINLOSS();
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    public static void getInstruction() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = "CabinPressurization";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            Thread.currentThread().setName("Cabin Pressurization System (1)");
            System.out.println(threadName + " -> Cabin Pressurization Pumps ~~ "+ m + "  -> Cabin Pressure Resetted to 11.50PSI");
            currentPressure.set(1150);
        },x->{});
    }
    
    public static void getInstructionCABINLOSS() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchangeCABINLOSS";
                
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();
        
        chan.exchangeDeclare(ex,"fanout"); //fanout
        
        //get queue
        String qName = chan.queueDeclare().getQueue();
        
        //connect/bind queue with exchange
        chan.queueBind(qName,ex,""); //fanout: key -> ""
        
        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            try{
                Thread.currentThread().setName("Cabin Pressurization Systems (2)");
                System.out.println(threadName + " -> Cabin Pressurization Pumps ~~ "+ CabinPressurizationCabinLossInstruction + "  -> Awaiting Cabin Pressure Become Normal");
            }catch(Exception e){}
        },x->{});
        
        
    }
}