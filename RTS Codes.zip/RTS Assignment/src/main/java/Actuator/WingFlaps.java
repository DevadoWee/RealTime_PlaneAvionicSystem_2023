/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actuator;

import static Main.Constant_Phrase.WingFlapsDownInstruction;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David
 */
public class WingFlaps implements Runnable {
    static AtomicInteger currentAltitude;
    public WingFlaps(AtomicInteger currentAltitude){
        this.currentAltitude = currentAltitude;
    }
    @Override
    public void run() {
        try {
            Thread.currentThread().setName("WingFlaps Systems");
            getInstruction();
            getInstructionCABINLOSS();
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    public static void getInstruction() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = "WingFlaps";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            Thread.currentThread().setName("WingFlaps Systems (1)");
            System.out.println(threadName + " -> WingFlaps Flaps ~~ "+ m + "  -> Altitude Resetted to 150000ft");
            currentAltitude.set(15000);
        },x->{});
    }
    
    public static void getInstructionCABINLOSS() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchangeCABINLOSS";
                
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();
        
        chan.exchangeDeclare(ex,"fanout"); //fanout
        
        //get queue
        String qName = chan.queueDeclare().getQueue();
        
        //connect/bind queue with exchange
        chan.queueBind(qName,ex,""); //fanout: key -> ""
        
        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            try{
                Thread.currentThread().setName("WingFlaps (2)");
                System.out.println(threadName + " ------------> WingFlaps Flaps ~~ "+ WingFlapsDownInstruction + "  -> Awaiting Cabin Pressure Become Normal");
            }catch(Exception e){}
        },x->{});
        
        
    }
}
