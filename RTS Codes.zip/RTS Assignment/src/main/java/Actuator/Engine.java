/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actuator;

import static Main.Constant_Phrase.EngineSlowInstruction;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author David
 */
public class Engine implements Runnable{
    static AtomicInteger currentSpeed;
    public Engine(AtomicInteger currentSpeed){
        this.currentSpeed = currentSpeed;
    }
    
    @Override
    public void run() {
        try {
            Thread.currentThread().setName("Engine Systems");
            getInstruction();
            getInstructionCABINLOSS();
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    public static void getInstruction() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchange";
        String key = "Engine";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""

        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        Thread.currentThread().setName("Engine Systems (1)");
        String m = new String(msg.getBody(),"UTF-8");
            System.out.println(threadName + " -> Engine System ~~ "+ m + "  -> Speed Resetted to 900km/h");
            currentSpeed.set(900);
        },x->{});
    }
    
    public static void getInstructionCABINLOSS() throws IOException, TimeoutException{
        String ex = "ActuatorDirectExchangeCABINLOSS";
                
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();
        
        chan.exchangeDeclare(ex,"fanout"); //fanout
        
        //get queue
        String qName = chan.queueDeclare().getQueue();
        
        //connect/bind queue with exchange
        chan.queueBind(qName,ex,""); //fanout: key -> ""
        
        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        Thread.currentThread().setName("Engine System (2)");
        String m = new String(msg.getBody(),"UTF-8");
            try{
                System.out.println(threadName + " -> Engine System ~~ "+ EngineSlowInstruction + "  -> Awaiting Cabin Pressure Become Normal");
            }catch(Exception e){}
        },x->{});
        
        
    }
}
