/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Unexpected_Events;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David
 */
public class LossOfCabinPressure implements Runnable {

    Random rand = new Random();
    AtomicInteger startLossOfCabinPressure;
    
    public LossOfCabinPressure(AtomicInteger startLossOfCabinPressure){
        this.startLossOfCabinPressure =  startLossOfCabinPressure;
    }
    
    @Override
    public void run() {
        double sleepDuration = rand.doubles(0,7)
                                    .findFirst()           
                                    .getAsDouble(); 
        try {
            Thread.sleep((long) (sleepDuration * 1000)); //sleep for seconds
            System.out.println("-------------------------------------------------------------------------------CABIN-LOSS-EVENT-START--------------------------------------------------------");
            startLossOfCabinPressure.getAndIncrement(); //  add to one, event happens
            Thread.sleep(10000);
            System.out.println("-------------------------------------------------------------------------------CABIN-LOSS-EVENT-END--------------------------------------------------------");
            startLossOfCabinPressure.getAndSet(0);
        } catch (Exception e) {
            
        }
    }
    
}
