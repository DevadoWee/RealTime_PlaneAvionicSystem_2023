/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Unexpected_Events;

import com.mycompany.Sensor.Altitude_Sensor;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David
 */
public class Altitude_SensorBackup implements Runnable{
    static AtomicInteger AltitudeSensorStatus = new AtomicInteger(0);
    AtomicInteger currentAltitude;
    
    public Altitude_SensorBackup(AtomicInteger currentAltitude){
        this.currentAltitude =  currentAltitude;
    }
    
    @Override
    public void run() {
        try {
            getAltitude();
            ScheduledExecutorService Events = Executors.newScheduledThreadPool(1);
            Events.execute(new detectHaltedSensor(currentAltitude,AltitudeSensorStatus));
            
        } catch (Exception e) {}
    }
    
    public static void getAltitude() throws IOException, TimeoutException{
        String ex = "SensoryExchange";
        String key = "Altitude";
            
        ConnectionFactory cf = new ConnectionFactory();
        Connection con = cf.newConnection();
        Channel chan = con.createChannel();

        chan.exchangeDeclare(ex,"direct"); //fanout

        //get queue
        String qName = chan.queueDeclare().getQueue();

        //connect/bind queue with exchange
        chan.queueBind(qName,ex,key); //fanout: key -> ""
        
        //thread name
        String threadName = Thread.currentThread().getName();
        
        chan.basicConsume(qName,(x, msg)->{
        String m = new String(msg.getBody(),"UTF-8");
            try {
                AltitudeSensorStatus.incrementAndGet();
            } catch (Exception ex1) {}
        },x->{});
    }
    
    static class detectHaltedSensor implements Runnable{
        AtomicInteger AltitudeSensorStatus;
        AtomicInteger currentAltitude;
        
        public detectHaltedSensor(AtomicInteger currentAltitude,AtomicInteger AltitudeSensorStatus){
            this.AltitudeSensorStatus = AltitudeSensorStatus;
            this.currentAltitude =  currentAltitude;
        }
        @Override
        public void run(){
            while (true){
                int status1 = (int) AltitudeSensorStatus.get();
                try{
                    Thread.sleep(2500);
                    int status2 = (int) AltitudeSensorStatus.get();
                    if ((status2 - status1 == 0)){
                        System.out.println("ALTITUDE SENSOR FAILURE *DETECTED, RE-EXECUTING ALTITUDE SENSOR." + status1 + "--" + status2);
                        ScheduledExecutorService Sensors = Executors.newScheduledThreadPool(1);
                        Sensors.scheduleAtFixedRate(new Altitude_Sensor(currentAltitude),0,1500,TimeUnit.MILLISECONDS);
                    }
                }catch(Exception e){

                }
            }
        }
    }
    
}
